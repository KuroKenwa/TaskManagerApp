package com.example.taskmanager.model

enum class Priority {
    LOW,
    MEDIUM,
    HIGH
}