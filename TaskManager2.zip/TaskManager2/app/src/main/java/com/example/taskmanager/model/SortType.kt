package com.example.taskmanager.model

enum class SortType {
    DATE,
    PRIORITY,
    STATUS
}