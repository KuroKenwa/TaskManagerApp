package com.example.taskmanager.model

enum class TaskStatus {
    PENDING,
    COMPLETED
}